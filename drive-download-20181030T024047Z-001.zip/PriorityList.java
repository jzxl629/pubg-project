public class PriorityList {

    public PriorityList(){

    }
}
