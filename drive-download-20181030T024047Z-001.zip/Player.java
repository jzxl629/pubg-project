public class Player {
    int sfs;//seconds from start
    Coordinate location;//last recorded coordinate of the payer
    int distSafe;

    int weapon1;//0= no weapon, 1 = pistol, 2 = SMG, 3 = shotgun, 4 = rifle, 5 = sniper
    int weapon2;//0= no weapon, 1 = pistol, 2 = SMG, 3 = shotgun, 4 = rifle, 5 = sniper
    int ammo1;
    int ammo2;
    int banddage;
    int medkit;
    int firstkit;
    int drinks;
    boolean vehicle;
}
